document.addEventListener("DOMContentLoaded",()=>{
const password = document.getElementById("password");
const email = document.getElementById("email");
const btn = document.getElementById("btn-login");

btn.onclick = function() {
    if (password.value !== "" && email.value !== "") {


        const storedEmail = localStorage.getItem("userEmail");
        const storedPassword = localStorage.getItem("userPassword");

        if (email.value === storedEmail && password.value === storedPassword) {
            // Open the home page
            var homePage = window.open('home-index.html', '_self');
            // Wait for the page to load before sending the message
            setTimeout(() => {
                homePage.postMessage('removeDiv', '*');
            }, 500);
        } else {
            alert("Incorrect email or password!");
        }
    } else {
        alert("Please fill in all fields.");
    }
        
    //     if(email.value === localStorage.getItem(userEmail) && password.value === localStorage.getItem(userPassword)){
    //         var homePage = window.open('home-index.html');
    //         homePage.postMessage('removeDiv', '*');
            
    //     }else{
    //         alert("Write the correct Gmail or Password!")
    //     }
    // }else{
    //     alert("Please fill in all Field(s)")
    // }
}


})