function myFunction() {
    var x = document.getElementsByClassName("navigation");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }
  window.addEventListener('message', function(event) {
    console.log('Message received:', event.data);
    if (event.data === 'removeDiv') {
        console.log('Removing div');
        var divToRemove = document.getElementById('btn-container');
        divToRemove.style.display = "none";
    }
});