let name = document.getElementById("name");
let email = document.getElementById("email");
let feedback = document.getElementById("feedback");
let btn = document.getElementById("btn");

btn.onclick = function(){
    if(name.value !== "" && email.value !== "" && feedback.value != ""){
        name.value = "";
        email.value = "";
        feedback.value = "";
        alert("Thanks for Your Feedback!") 
    }else{
        alert("Please fill in all Field(s)")
    }
}