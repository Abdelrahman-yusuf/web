let btn = document.getElementById("btn-signup");
let password = document.getElementById("password");
let email = document.getElementById("email");


btn.onclick = function(){ 
    if(password.value !== "" && email.value !== ""){
        // Store user data securely (you can use localStorage for this example)
        localStorage.setItem("userEmail", email.value);
        localStorage.setItem("userPassword", password.value);
        alert("Sign up successful! You can now log in.");
        window.location.href = "signin-index.html";
    } else {
        alert("Please fill in all fields.");
    }
}