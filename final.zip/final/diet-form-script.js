const btnSubmit = document.getElementById("btn-submit");
const plan1 = document.getElementById("plan1");
const plan2 = document.getElementById("plan2");
const plan3 = document.getElementById("plan3");
const gridiant = document.getElementById("gridiant");
const tallInput = document.getElementById("tall");
const weightInput = document.getElementById("wieght");

function calculateBMI(weight, height) {
    const heightInMeters = height / 100;
    return weight / (heightInMeters * heightInMeters);
}

function showPlan(bmi) {
    
    plan1.classList.add("hidden");
    plan2.classList.add("hidden");
    plan3.classList.add("hidden");
    
    if (bmi < 18.5) {
        plan3.classList.remove("hidden");
    } else if (bmi >= 18.5 && bmi < 25) {
        plan1.classList.remove("hidden");
    } else {
        plan2.classList.remove("hidden");
    }
    
    gridiant.classList.remove("hidden");
}

function validateInput(value, min, max) {
    const num = parseFloat(value);
    return !isNaN(num) && num >= min && num <= max;
}

btnSubmit.addEventListener("click", function() {
    const height = parseFloat(tallInput.value);
    const weight = parseFloat(weightInput.value);
    
    if (!validateInput(height, 100, 250) || !validateInput(weight, 30, 300)) {
        alert("Please enter valid height (100-250 cm) and weight (30-300 kg).");
        return;
    }
    
    const bmi = calculateBMI(weight, height);
    showPlan(bmi);
    this.scroll({
        bottom: "1000px",
        behavior: "smooth"
    })
});